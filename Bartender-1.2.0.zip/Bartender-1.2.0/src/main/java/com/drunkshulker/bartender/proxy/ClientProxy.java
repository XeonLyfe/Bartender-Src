package com.drunkshulker.bartender.proxy;

public class ClientProxy extends CommonProxy{
	
	@Override
	public void init() {
		
	}
	
}
