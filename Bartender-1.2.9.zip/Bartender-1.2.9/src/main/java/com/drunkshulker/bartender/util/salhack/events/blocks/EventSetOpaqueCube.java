package com.drunkshulker.bartender.util.salhack.events.blocks;

import com.drunkshulker.bartender.util.salhack.events.MinecraftEvent;

public class EventSetOpaqueCube extends MinecraftEvent
{
}
