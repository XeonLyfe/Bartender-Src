package org.newdawn.slick;


public interface InputListener extends MouseListener, KeyListener, ControllerListener {
}
