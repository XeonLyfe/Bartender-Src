package org.newdawn.slick;


public interface Renderable {

	
	public void draw(float x, float y);
	
}
