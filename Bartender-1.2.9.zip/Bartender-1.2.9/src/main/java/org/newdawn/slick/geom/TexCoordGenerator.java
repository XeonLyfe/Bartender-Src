package org.newdawn.slick.geom;


public interface TexCoordGenerator {
	
	public Vector2f getCoordFor(float x, float y);
}
