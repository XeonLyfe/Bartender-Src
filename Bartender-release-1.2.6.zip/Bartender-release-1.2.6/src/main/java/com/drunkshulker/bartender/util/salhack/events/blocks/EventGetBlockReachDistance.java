package com.drunkshulker.bartender.util.salhack.events.blocks;

import com.drunkshulker.bartender.util.salhack.events.MinecraftEvent;

public class EventGetBlockReachDistance extends MinecraftEvent
{
    public float BlockReachDistance = 0.0f;
    
    public EventGetBlockReachDistance()
    {
        super();
    }
}
