package com.drunkshulker.bartender.util.salhack.events.player;

import com.drunkshulker.bartender.util.salhack.events.MinecraftEvent;
import net.minecraft.entity.MoverType;

public class EventPlayerElytraFlying extends MinecraftEvent
{
    public EventPlayerElytraFlying()
    {
    }
    
    public boolean Is;
}
