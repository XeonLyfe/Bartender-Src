package org.newdawn.slick.muffin;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import org.newdawn.slick.util.Log;


public class WebstartMuffin implements Muffin {

	
	public void saveFile(HashMap scoreMap, String fileName) throws IOException {

	}

	
	public HashMap loadFile(String fileName) throws IOException {
		HashMap hashMap = new HashMap();

		return hashMap;
	}
}
