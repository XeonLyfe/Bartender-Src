package org.newdawn.slick.particles;


public interface ConfigurableEmitterFactory {
	
	public ConfigurableEmitter createEmitter(String name);
}
