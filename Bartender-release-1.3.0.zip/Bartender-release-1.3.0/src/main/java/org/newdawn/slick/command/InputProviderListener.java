package org.newdawn.slick.command;


public interface InputProviderListener {

     
    public void controlPressed(Command command);

     
    public void controlReleased(Command command);
}
