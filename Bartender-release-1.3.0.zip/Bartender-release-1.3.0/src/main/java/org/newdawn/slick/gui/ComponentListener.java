package org.newdawn.slick.gui;


public interface ComponentListener {

	
	public void componentActivated(AbstractComponent source);
}
