package org.newdawn.slick;


public interface MusicListener {

	
	public void musicEnded(Music music);
	
	
	public void musicSwapped(Music music, Music newMusic);
}
