package com.drunkshulker.bartender.mixins.client;

import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.client.renderer.ActiveRenderInfo;

@Mixin(ActiveRenderInfo.class)
public class MixinActiveRenderInfo
{
    
}
