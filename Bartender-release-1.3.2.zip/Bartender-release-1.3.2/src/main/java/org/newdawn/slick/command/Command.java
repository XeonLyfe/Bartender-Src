package org.newdawn.slick.command;


public interface Command {

}
